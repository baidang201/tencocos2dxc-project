#include "HelloWorldScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;

using namespace cocostudio::timeline;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    auto rootNode = CSLoader::createNode("MainScene.csb");
    addChild(rootNode);
    
    //��ø�layout��֮����Ҫ��һ����layout����Ϊ��ʹ��Helper::seekWidgetByName����
    root = static_cast<Layout*>( rootNode->getChildByName("root") );
    

	spriteFlight = static_cast<Sprite*>(root->getChildByName("spriteFlight"));
	spriteFlight->setScale(2);
	addChild(spriteFlight);

	spriteMove = static_cast<Sprite*>(root->getChildByName("spriteMove"));
	spriteMove->setScale(2);
	addChild(spriteMove);

	SetAnimation(spriteFlight, "flight", 16);
	SetAnimation(spriteMove, "move", 8);

    return true;
}


void  HelloWorld::SetAnimation(Sprite* sprite,const char *name_each,unsigned int num)
{
	if(nullptr == sprite)
	{
		return;
	}

	CCAnimation* animation = CCAnimation::create();  
	for( int i=0;i<num;i++)  
	{  
		char szName[100] = {0};  
		sprintf(szName,"%s_%d.png",name_each,i);  
		animation->addSpriteFrameWithFileName(szName); //���ض�����֡  
	}  
	animation->setDelayPerUnit(2.8f / 14.0f);  
	animation->setRestoreOriginalFrame(true);  
	animation->setLoops(-1); //����ѭ��
	//��������װ��һ������
	CCAnimate* act=CCAnimate::create(animation);

    sprite->runAction(act);
}
