#ifndef __RUNTIMEPARAM_H__
#define __RUNTIMEPARAM_H__

#include "cocos2d.h"
#include "HelloWorldScene.h"
#include "SecondScene.h"

class RuntimeParam
{
public:
	static RuntimeParam* getInstance();
	Vector<Scene*> m_Scenes;

private:
	static RuntimeParam* _instance;

	RuntimeParam();
	~RuntimeParam();
};


#endif /* defined(__RuntimeParam__) */