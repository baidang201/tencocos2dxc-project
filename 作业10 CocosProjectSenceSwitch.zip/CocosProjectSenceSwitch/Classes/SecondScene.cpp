#include "SecondScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"

USING_NS_CC;

using namespace cocostudio::timeline;

Scene* SecondScene::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = SecondScene::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool SecondScene::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    auto rootNode = CSLoader::createNode("SecondScene.csb");

    addChild(rootNode);

	root = static_cast<Layout*>(rootNode->getChildByName("root"));

	btnSwitchScene = static_cast<Button*> (Helper::seekWidgetByName(root, "btnSwitchScene"));
	btnSwitchScene->setTouchEnabled(true);
	btnSwitchScene->addTouchEventListener(CC_CALLBACK_2(SecondScene::switchSceneEvent, this));

    return true;
}


void SecondScene::switchSceneEvent(Ref* pSender, Widget::TouchEventType type)
{
	if(type == Widget::TouchEventType::ENDED)
	{
		Director::getInstance()->replaceScene(RuntimeParam::getInstance()->m_Scenes.at(0));
	}
}