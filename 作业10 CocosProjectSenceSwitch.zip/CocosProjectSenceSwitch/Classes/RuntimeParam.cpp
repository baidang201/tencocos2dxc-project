#include "RuntimeParam.h"

RuntimeParam* RuntimeParam::_instance = nullptr;

RuntimeParam* RuntimeParam::getInstance()
{
	if(nullptr == _instance)
	{
		_instance = new RuntimeParam();
	}
	return _instance;
}

RuntimeParam::RuntimeParam()
{
	Scene* pHelloWorld = HelloWorld::createScene();
	Scene* pSecondScene = SecondScene::createScene();

	m_Scenes = Vector<Scene*>();
	m_Scenes.pushBack(pHelloWorld);
	m_Scenes.pushBack(pSecondScene);
}

RuntimeParam::~RuntimeParam()
{
}