﻿#include "HelloWorldScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "json/rapidjson.h"
#include "json/document.h"
#include "json/stringbuffer.h"
#include "json/writer.h"


USING_NS_CC;

using namespace cocostudio::timeline;
using namespace  rapidjson;

const int maxHeros = 2;

Scene* HelloWorld::createScene()
{
	// 'scene' is an autorelease object
	auto scene = Scene::create();

	// 'layer' is an autorelease object
	auto layer = HelloWorld::create();

	// add layer as a child to scene
	scene->addChild(layer);

	// return the scene
	return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
	//////////////////////////////
	// 1. super init first
	if ( !Layer::init() )
	{
		return false;
	}

	auto rootNode = CSLoader::createNode("MainScene.csb");

	addChild(rootNode);

	root = static_cast<Layout*>(rootNode->getChildByName("root"));

	btnTojson = static_cast<Button*> (Helper::seekWidgetByName(root, "btnTojson"));
	btnTojson->setTouchEnabled(true);
	btnTojson->addTouchEventListener(CC_CALLBACK_2(HelloWorld::TojsonEvent, this));


	btnParse = static_cast<Button*> (Helper::seekWidgetByName(root, "btnParse"));
	btnParse->setTouchEnabled(true);
	btnParse->addTouchEventListener(CC_CALLBACK_2(HelloWorld::ParseEvent, this));

	txtBefore = static_cast<Text*> (Helper::seekWidgetByName(root, "txtBefore"));
	txtJson = static_cast<Text*> (Helper::seekWidgetByName(root, "txtJson"));
	txtAfterParse = static_cast<Text*> (Helper::seekWidgetByName(root, "txtAfterParse"));

	vectHeros = new Vector<HeroModel*>();



	for(int i = 0; i<maxHeros; i++)
	{
		char szName[128];
		char szComment[128];
		sprintf(szName, "hero%d", i);
		sprintf(szComment, "heroComment%d", i);
		HeroModel* hero = new HeroModel(i, szName, szComment, 100*i, 1000*i, 2*i,   3*i);
		vectHeros->pushBack(hero);
	}

	FileUtils::getInstance()->addSearchPath("D:/CocosDocuments/Cocos/CocosProjects/CocosJsonParse/Resources/");
	FileUtils::getInstance()->addSearchPath("D:/CocosDocuments/Cocos/CocosProjects/CocosJsonParse/proj.win32/Debug.win32");

	return true;
}

void HelloWorld::TojsonEvent(Ref* pSender, Widget::TouchEventType type)
{
	if(type == Widget::TouchEventType::ENDED)
	{
		rapidjson::Document document;
		document.SetObject();
		rapidjson::Document::AllocatorType& allocator = document.GetAllocator();
		rapidjson::Value array(rapidjson::kArrayType);

		string strHeros = "";
		char szHeros[256] = "";
		for(int i = 0; i<maxHeros; i++)
		{
			HeroModel* hero = vectHeros->at(i);
			rapidjson::Value object(rapidjson::kObjectType);
			object.AddMember("heroName", hero->m_heroName.c_str(), allocator);
			object.AddMember("HP", hero->m_HP, allocator);
			object.AddMember("MP", hero->m_MP, allocator);
			object.AddMember("attack", hero->m_attack, allocator);
			object.AddMember("defense", hero->m_defense, allocator);
			array.PushBack(object, allocator);
			sprintf(szHeros,  "heroName:%s HP:%f  MP:%f attack:%f  defense:%f\n", 
				hero->m_heroName.c_str(), 
 				hero->m_HP, 
				hero->m_MP, 
				hero->m_attack, 
				hero->m_defense );
			strHeros+=szHeros;
		}
		txtBefore->setString(strHeros);
		document.AddMember("heros", array, allocator);

		StringBuffer buffer;
		rapidjson::Writer<StringBuffer> writer(buffer);
		document.Accept(writer);
		CCLOG("%s",buffer.GetString());

		char szPath[128];
		sprintf(szPath, "%test.json", FileUtils::getInstance()->getWritablePath() );
		FILE* pf = fopen(szPath, "wb");
		if(pf)
		{
			fwrite(buffer.GetString(), buffer.Size(),  1,pf);
			fclose(pf);
		}
	}
}


void HelloWorld::ParseEvent(Ref* pSender, Widget::TouchEventType type)
{
	if(type == Widget::TouchEventType::ENDED)
	{
		ssize_t  size;
		string strFullPath = FileUtils::getInstance()->fullPathForFilename("test.json");
		unsigned char* ch=FileUtils::getInstance()->getFileData(strFullPath.c_str(),"r",&size);
		std::string data=std::string((const char*)ch,size);

		rapidjson::Document d;
		d.Parse<0>(data.c_str());
		if (d.HasParseError())  //打印解析错误
		{
			CCLOG("GetParseError %s\n",d.GetParseError());
		}

		if (d.IsObject() && d.HasMember("heros")) 
		{
			txtJson->setString(data);
			const rapidjson::Value &heros =  d["heros"];

			if(heros.IsArray())
			{
				string strHeros = "";
				char szHeros[256] = "";
				for(int i = 0; i<heros.Capacity(); i++)
				{
					const rapidjson::Value &item = heros[i];  
					if(item.IsObject() && item.HasMember("heroName"))
					{
						CCLOG("%s\n", item["heroName"].GetString());
					}
					if(item.IsObject() && item.HasMember("HP"))
					{
						CCLOG("%lf\n", item["HP"].GetDouble());
					}
					if(item.IsObject() && item.HasMember("MP"))
					{
						CCLOG("%lf\n", item["MP"].GetDouble());
					}
					if(item.IsObject() && item.HasMember("attack"))
					{
						CCLOG("%lf\n", item["attack"].GetDouble());
					}
					if(item.IsObject() && item.HasMember("defense"))
					{
						CCLOG("%lf\n", item["defense"].GetDouble());
					}
					sprintf(szHeros,  "heroName:%s HP:%f  MP:%f attack:%f  defense:%f\n", 
						item["heroName"].GetString(), 
						item["HP"].GetDouble(), 
						item["MP"].GetDouble(), 
						item["attack"].GetDouble(), 
						item["defense"].GetDouble() );
					strHeros+=szHeros;
				}
				txtAfterParse->setString(strHeros);
			}
		}
	}
}