#include "HeroModel.h"

HeroModel::HeroModel()
{

}

HeroModel::HeroModel(int heroID, string heroName, string comment, double HP, double MP, double attack, double defense)
{
	//todo(liyh) ���ɺ�ģ�壿   m_#���� = ����
	m_heroID = heroID;
	m_heroName = heroName;
	m_comment = comment;

	m_HP = HP;
	m_MP = MP;
	m_attack = attack;
	m_defense = defense;
}

HeroModel::~HeroModel()
{

}

string HeroModel::getHeroImage()
{
	return "Hero/Hero" + this->m_comment + ".jpg";
}

string HeroModel::getPartnerImage()
{
	return "Partner/Partner" + this->m_comment + ".png";
}
