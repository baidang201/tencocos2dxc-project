#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "network\HttpRequest.h"
#include "network\HttpClient.h"

using namespace cocos2d::network;
USING_NS_CC;

using namespace cocostudio::timeline;
using namespace cocos2d::ui;


class HelloWorld : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();

    // implement the "static create()" method manually
    CREATE_FUNC(HelloWorld);

	void LoginEventGet(Ref* pSender, Widget::TouchEventType type);
	void HttpResponEventGet(HttpClient* client, HttpResponse* response);

	void LoginEventPost(Ref* pSender, Widget::TouchEventType type);
	void HttpResponEventPost(HttpClient* client, HttpResponse* response);
private:
	

	Layout* root;
	Button*  btnLoginGet;
	Button*  btnLoginPost;
	TextField*  txtUserName;
	TextField*  txtPassword;
};

#endif // __HELLOWORLD_SCENE_H__
