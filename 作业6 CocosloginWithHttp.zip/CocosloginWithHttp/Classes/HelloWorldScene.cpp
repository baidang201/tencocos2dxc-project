#include "HelloWorldScene.h"


Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    auto rootNode = CSLoader::createNode("MainScene.csb");

    addChild(rootNode);

	root = static_cast<Layout*>(rootNode->getChildByName("root"));


	btnLoginGet = static_cast<Button*> (Helper::seekWidgetByName(root, "btnLoginGet"));
	btnLoginGet->setTouchEnabled(true);
	btnLoginGet->addTouchEventListener(CC_CALLBACK_2(HelloWorld::LoginEventGet, this));

	btnLoginPost = static_cast<Button*> (Helper::seekWidgetByName(root, "btnLoginPost"));
	btnLoginPost->setTouchEnabled(true);
	btnLoginPost->addTouchEventListener(CC_CALLBACK_2(HelloWorld::LoginEventPost, this));

	txtUserName = static_cast<TextField*> (Helper::seekWidgetByName(root, "txtUserName"));


	txtPassword = static_cast<TextField*> (Helper::seekWidgetByName(root, "txtPassword"));

    return true;
}

void HelloWorld::LoginEventGet(Ref* pSender, Widget::TouchEventType type)
{
	if (type == Widget::TouchEventType::ENDED)
	{				
			HttpRequest* req = new HttpRequest();

			req->setRequestType(HttpRequest::Type::GET);
			req->setResponseCallback(CC_CALLBACK_2(HelloWorld::HttpResponEventGet, this));

			char szFullUrl[512];
			sprintf(szFullUrl, "http://127.0.0.1:8081/DoLogin?username=%s&password=%s", txtUserName->getString().c_str(), txtPassword->getString().c_str());
			req->setUrl(szFullUrl);

			HttpClient::getInstance()->send(req);

			req->release();
	
	}
}

void HelloWorld::HttpResponEventGet(HttpClient* client, HttpResponse* response)
{
	if (!response) { CCLOG("Log:response =null,plase check it."); return; }

	if (!response->isSucceed())
	{
		CCLOG("ERROR BUFFER:%s", response->getErrorBuffer());
		return;
	}

	int codeIndex = response->getResponseCode();

	std::vector<char>* buffer = response->getResponseData();
	std::string temp(buffer->begin(), buffer->end());

	rapidjson::Document d;
	d.Parse<0>(temp.c_str());
	if (d.HasParseError())  
	{
		CCLOG("GetParseError %s\n", d.GetParseError());
	}

	if (d.IsObject() && d.HasMember("accept"))
	{
		const rapidjson::Value &acceptValue = d["accept"];
		if (acceptValue.IsString())
		{
			CCLOG(acceptValue.GetString());
		}
	}

	CCLOG(temp.c_str());
}

void HelloWorld::LoginEventPost(Ref* pSender, Widget::TouchEventType type)
{
	if (type == Widget::TouchEventType::ENDED)
	{

		HttpRequest* req = new HttpRequest();
		req->setUrl("http://127.0.0.1:8081/DoLogin");
		req->setRequestType(HttpRequest::Type::POST);
		req->setResponseCallback(CC_CALLBACK_2(HelloWorld::HttpResponEventPost, this));

		char szParam[512];
		sprintf(szParam, "username=%s&password=%s", txtUserName->getString().c_str(), txtPassword->getString().c_str());
		req->setRequestData(szParam, strlen(szParam));

		HttpClient::getInstance()->send(req);
		req->release();


	}
}

void HelloWorld::HttpResponEventPost(HttpClient* client, HttpResponse* response)
{
	if (!response) { CCLOG("Log:response =null,plase check it."); return; }

	if (!response->isSucceed())
	{
		CCLOG("ERROR BUFFER:%s", response->getErrorBuffer());
		return;
	}

	int codeIndex = response->getResponseCode();

	std::vector<char>* buffer = response->getResponseData();
	std::string temp(buffer->begin(), buffer->end());

	rapidjson::Document d;
	d.Parse<0>(temp.c_str());
	if (d.HasParseError())
	{
		CCLOG("GetParseError %s\n", d.GetParseError());
	}

	if (d.IsObject() && d.HasMember("accept"))
	{
		const rapidjson::Value &acceptValue = d["accept"];
		if (acceptValue.IsString())
		{
			CCLOG(acceptValue.GetString());
		}
	}

	CCLOG(temp.c_str());
}