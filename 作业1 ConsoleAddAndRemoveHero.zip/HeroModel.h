#ifndef __HEROMODEL_H__
#define __HEROMODEL_H__

#include <string>
#include <iostream>

using namespace std;

class HeroModel 
{
public:
	HeroModel();
	HeroModel(int heroID, string heroName, string state, double HP, double attack, double defense);
	~HeroModel();


	int m_heroID;
	string m_heroName;
	string m_comment;
	string getHeroImage();
	string getPartnerImage();


	double m_HP;
	double m_attack;
	double m_defense;
};

#endif