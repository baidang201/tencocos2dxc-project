#include <iostream>
#include <string>
#include <map>
#include "HeroModel.h"

using namespace std;

map<int, HeroModel> mapHeros;
map<int, HeroModel> mapMyHeros;

int initmapHeros()
{
	mapHeros[0 ]=(HeroModel(0, "alibaba", "", 900, 15, 50));
	mapHeros[1] = (HeroModel(1, "baidu", "", 800, 10, 60));
	mapHeros[2] = (HeroModel(2, "tencent", "", 900, 20, 50));
	mapHeros[3] = (HeroModel(3, "xiaomi", "", 800, 15, 100));

	return 0;
}

int menu()
{
	int choice = -1;
	cout << "*** Menu ***" << endl;
	cout << "1 Add Hero To My Team " << endl;
	cout << "2 Remove Hero From My Team " << endl;
	cout << "3 View All Team " << endl;
	cout << "0 Quit " << endl;
	
	cin >> choice;
	return choice;
}

int AddHero()
{
	int ID = -1;
	cout << "please input hero ID in Pulic Hero Team " << endl;;
	cin >> ID;

	if (mapHeros.find(ID) == mapHeros.end())
	{
		cout << "Bad ID, please check in Pulic Hero List"<< endl;
		return -1;
	}

	// iterate foo: inserting into bar
	if (mapMyHeros.find(ID) == mapMyHeros.end())
	{
		mapMyHeros[ID] = mapHeros[ID];
		cout << "Add OK!" << endl;
	}
	else
	{
		cout << "had Added, not more" << endl;
		return -1;
	}

	return 0;

}

int RemoveHero()
{
	int ID = -1;
	cout << "please input hero ID in My Hero Team " << endl;;
	cin >> ID;

	if (mapMyHeros.find(ID) == mapMyHeros.end())
	{
		cout << "Bad ID, please check in My Hero List" << endl;
		return -1;
	}

	// iterate foo: inserting into bar
	if (mapMyHeros.find(ID) != mapMyHeros.end())
	{
		mapMyHeros.erase(ID);
		cout << "Remove OK!" << endl;
	}
	else
	{
		cout << "had Added, not more" << endl;
		return -1;
	}

	return 0;

}

int ViewHeros()
{
	cout << "Here is public Team! Count is "<< mapHeros.size()<< endl;
	map<int, HeroModel>::iterator it = std::begin(mapHeros);
	for (; it != std::end(mapHeros); it++)
	{
		HeroModel hero = it->second;
		cout << "ID:" << hero.m_heroID << " name:" << hero.m_heroName << " HP:" << hero.m_HP << " attack:" << hero.m_attack << " defense:" << hero.m_defense<<endl;
	}

	cout << endl;
	cout << "Here is My Team! Count is " << mapMyHeros.size()<< endl;
	it = std::begin(mapMyHeros);
	for (; it != std::end(mapMyHeros); it++)
	{
		HeroModel hero = it->second;
		cout << "ID:" << hero.m_heroID << " name:" << hero.m_heroName << " HP:" << hero.m_HP << " attack:" << hero.m_attack << " defense:" << hero.m_defense << endl;

	}
	cout << endl;

	return 0;
}

int main()
{
	initmapHeros();

	bool exit = false;
	while (true)
	{
		int choice = menu();
		switch (choice)
		{
		case 1:
			AddHero();
			break;
		case 2:
			RemoveHero();
			break;
		case 3:
			ViewHeros();
			break;
		case 0:
			exit = true;
			break;
		default:
			break;
		}

		if (exit)
		{
			break;
		}
	}


	return 0;
}