#ifndef __HELLOWORLD_SCENE_H__
#define __HELLOWORLD_SCENE_H__

#include "cocos2d.h"
#include "cocostudio\CocoStudio.h"
#include "ui/CocosGUI.h"

using namespace cocos2d::ui;

class HelloWorld : public cocos2d::Layer
{
public:
    // there's no 'id' in cpp, so we recommend returning the class instance pointer
    static cocos2d::Scene* createScene();

    // Here's a difference. Method 'init' in cocos2d-x returns bool, instead of returning 'id' in cocos2d-iphone
    virtual bool init();

    // implement the "static create()" method manually
    CREATE_FUNC(HelloWorld);

	void PlayEvent(Ref* pSender, Widget::TouchEventType type);
	void PauseEvent(Ref* pSender, Widget::TouchEventType type);
	void ResumeEvent(Ref* pSender, Widget::TouchEventType type);
	void StopEvent(Ref* pSender, Widget::TouchEventType type);
	void EffectEvent(Ref* pSender, Widget::TouchEventType type);

	char szBack[512];
	char szEffect[512];

private:
	Layout* root;
	Button* btnPlay;
	Button* btnPause;
	Button* btnResume;
	Button* btnStop;
	Button* btnEffect;
};

#endif // __HELLOWORLD_SCENE_H__
