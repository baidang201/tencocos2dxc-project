#include "HelloWorldScene.h"
#include "cocostudio/CocoStudio.h"
#include "ui/CocosGUI.h"
#include "SimpleAudioEngine.h"

USING_NS_CC;

using namespace cocostudio::timeline;
using namespace CocosDenshion;

Scene* HelloWorld::createScene()
{
    // 'scene' is an autorelease object
    auto scene = Scene::create();
    
    // 'layer' is an autorelease object
    auto layer = HelloWorld::create();

    // add layer as a child to scene
    scene->addChild(layer);

    // return the scene
    return scene;
}

// on "init" you need to initialize your instance
bool HelloWorld::init()
{
    //////////////////////////////
    // 1. super init first
    if ( !Layer::init() )
    {
        return false;
    }
    
    auto rootNode = CSLoader::createNode("MainScene.csb");

    addChild(rootNode);

	root = static_cast<Layout*> (rootNode->getChildByName("root"));

	btnPlay = static_cast<Button*> (Helper::seekWidgetByName(root, "btnPlay"));
	btnPlay->setTouchEnabled(true);
	btnPlay->addTouchEventListener(CC_CALLBACK_2(HelloWorld::PlayEvent, this));
	

	btnPause = static_cast<Button*> (Helper::seekWidgetByName(root, "btnPause"));
	btnPause->setTouchEnabled(true);
	btnPause->addTouchEventListener(CC_CALLBACK_2(HelloWorld::PauseEvent, this));
	

	btnResume = static_cast<Button*> (Helper::seekWidgetByName(root, "btnResume"));
	btnResume->setTouchEnabled(true);
	btnResume->addTouchEventListener(CC_CALLBACK_2(HelloWorld::ResumeEvent, this));
	

	btnStop = static_cast<Button*> (Helper::seekWidgetByName(root, "btnStop"));
	btnStop->setTouchEnabled(true);
	btnStop->addTouchEventListener(CC_CALLBACK_2(HelloWorld::StopEvent, this));
	

	btnEffect = static_cast<Button*> (Helper::seekWidgetByName(root, "btnEffect"));
	btnEffect->setTouchEnabled(true);
	btnEffect->addTouchEventListener(CC_CALLBACK_2(HelloWorld::EffectEvent, this));

	strcpy(szBack, "OP.mp3");
	strcpy(szEffect, "bird_02.wav");
	SimpleAudioEngine::getInstance()->preloadBackgroundMusic(szBack);
    SimpleAudioEngine::getInstance()->preloadEffect(szEffect);

    return true;
}

void HelloWorld::PlayEvent(Ref* pSender, Widget::TouchEventType type)
{
	if(type == Widget::TouchEventType::ENDED)
	{
		SimpleAudioEngine::getInstance()->playBackgroundMusic(szBack, true);
	}
}


void HelloWorld::PauseEvent(Ref* pSender, Widget::TouchEventType type)
{
	if(type == Widget::TouchEventType::ENDED)
	{
		SimpleAudioEngine::getInstance()->pauseBackgroundMusic();
	}
}


void HelloWorld::ResumeEvent(Ref* pSender, Widget::TouchEventType type)
{
	if(type == Widget::TouchEventType::ENDED)
	{
		SimpleAudioEngine::getInstance()->resumeBackgroundMusic();
	}
}


void HelloWorld::StopEvent(Ref* pSender, Widget::TouchEventType type)
{
	if(type == Widget::TouchEventType::ENDED)
	{
		SimpleAudioEngine::getInstance()->stopBackgroundMusic();
	}
}


void HelloWorld::EffectEvent(Ref* pSender, Widget::TouchEventType type)
{
	if(type == Widget::TouchEventType::ENDED)
	{
		SimpleAudioEngine::getInstance()->playEffect(szEffect);
	}
}

