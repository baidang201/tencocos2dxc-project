require("src/cocos/cocos2d/json")
local scene

-- cclog   
local cclog = function(...)   
    release_print(string.format(...)) --sometime release_print work!   
end   

local function init()
    scene = cc.Scene:create()
    local rootNode = cc.CSLoader:createNode("MainScene.csb")
    scene:addChild(rootNode)    

    local root = rootNode:getChildByName("root")   

    local btnTojson = ccui.Helper:seekWidgetByName(root, "btnTojson")
    local btnParse = ccui.Helper:seekWidgetByName(root, "btnParse")
    
    local txtBefore = ccui.Helper:seekWidgetByName(root, "txtBefore")
    local txtJson = ccui.Helper:seekWidgetByName(root, "txtJson")
    local txtAfterParse = ccui.Helper:seekWidgetByName(root, "txtAfterParse")
    
    local strBefore = ""  
    local t = {}
    for i=1, 4 do
        t[i] = {ID = i, Name = "Hero"..i, Comment = "Comment"..i, Attack = 100*i, Defence = 100*i, HP = 2*i, MP = 3*i}
        strBefore = string.format("%s \n name: %s  comment %s  attack:%d", strBefore, t[i].Name, t[i].Comment, t[i].Attack) 
    end  

    
    local function TojsonCallBack( sender, eventType )
        if eventType == ccui.TouchEventType.ended then
            cclog("btnTojson")      
            
            -- encode
            local herojsonData = json.encode(t)
            txtJson:setString(herojsonData)
            
            local path = cc.FileUtils:getInstance():getWritablePath() .. "jsonTest.txt"
            cclog(path)
            --cc.FileUtils:getInstance():writeDataToFile(herojsonData, path)    un binding writeDataToFile, so use io
            local file = assert( io.open(path, "w"))
            file:write(herojsonData)
            io.close(file)
        end
    end 

    local function ParseCallBack( sender, eventType )
        if eventType == ccui.TouchEventType.ended then
            cclog("btnParse")
            
            local path = cc.FileUtils:getInstance():getWritablePath() .. "jsonTest.txt"
            local herojsonData = cc.FileUtils:getInstance():getStringFromFile(path)
            cclog(string.format("parseJson %s", herojsonData))
            
            --decode     
            local heroafterT = json.decode(herojsonData)
            local strAfter = ""
            for key, var in pairs(heroafterT) do
                strAfter = string.format("%s \n name: %s  comment %s  attack:%d", strAfter, var.Name, var.Comment, var.Attack) 
            end
            txtAfterParse:setString(strAfter)
        end
    end    

    
    btnTojson:addTouchEventListener(TojsonCallBack)
    btnParse:addTouchEventListener(ParseCallBack)
    
    
    txtBefore:setString(strBefore)          
   
   
end

init()

return scene