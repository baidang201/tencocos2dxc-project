local scene

-- cclog  
local cclog = function(...)  
    release_print(string.format(...)) 
    --print(string.format(...)) 
end  

local function switchToSecondCallBack( sender, eventType )
    cclog("click to second ok")
    if eventType == ccui.TouchEventType.ended then
        cclog("in ended to second %d", eventType)
        local t = require("secondScene")
        if t == nil then
            cclog("secondScene is nil")
        else 
            cclog("secondScene not nil")
        end
        cc.Director:getInstance():replaceScene(t)
    end
end 

local function init()
    scene = cc.Scene:create()
    local rootNode = cc.CSLoader:createNode("MainScene.csb")
    scene:addChild(rootNode)  
    local root = rootNode:getChildByName("root") 
    local btnSwitchScene = ccui.Helper:seekWidgetByName(root, "btnSwitchScene") 
    btnSwitchScene:setTouchEnabled(true)    
    btnSwitchScene:addTouchEventListener(switchToSecondCallBack)
end


init()

return scene

