local secondScene

-- cclog  
local cclog = function(...)  
    release_print(string.format(...)) 
    --print(string.format(...)) 
end  

local function switchToFirstCallBack( sender, eventType )
    cclog("click to first ok")
    if eventType == ccui.TouchEventType.ended then
        cclog("in ended to first %d", eventType) 
        local t = require("firstScene")
        if t == nil then
            cclog("first is nil")
        else 
            cclog("first not nil")
        end
        cc.Director:getInstance():replaceScene(t)
        if t == nil then
            cclog("first is nil again")
        else 
            cclog("first not nil again")
        end
    end
end 
    
    
local function init(parameters)
    secondScene = cc.Scene:create()
    local SecondrootNode = cc.CSLoader:createNode("SecondScene.csb")
    secondScene:addChild(SecondrootNode)
    local Secondroot =  SecondrootNode:getChildByName("root")
    local btnSwitchSceneSecond = ccui.Helper:seekWidgetByName(Secondroot, "btnSwitchScene")
    btnSwitchSceneSecond:setTouchEnabled(true)
    btnSwitchSceneSecond:addTouchEventListener(switchToFirstCallBack)    
end    


init()

return secondScene