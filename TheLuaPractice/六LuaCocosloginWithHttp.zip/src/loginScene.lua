local scene

-- cclog   
local cclog = function(...)   
    release_print(string.format(...)) --sometime release_print work!   
end   


local function init()
    scene = cc.Scene:create()
    local rootNode = cc.CSLoader:createNode("MainScene.csb")
    scene:addChild(rootNode)
    
    local root = rootNode:getChildByName("root")
    
    local btnLoginGet = ccui.Helper:seekWidgetByName(root, "btnLoginGet")
    local btnLoginPost = ccui.Helper:seekWidgetByName(root,"btnLoginPost")
    
    local txtUserName = ccui.Helper:seekWidgetByName(root,"txtUserName")
    local txtPassword = ccui.Helper:seekWidgetByName(root,"txtPassword")
    
    
    local function LoginGetCallBack(sender, eventType)
    	if eventType == ccui.TouchEventType.ended then
            cclog("get")
            local xhr = cc.XMLHttpRequest:new()
            xhr.responseTyep = cc.XMLHTTPREQUEST_RESPONSE_STRING
            xhr:open("GET", string.format("http://127.0.0.1:8081/DoLogin?username=%s&password=%s",txtUserName:getString(), txtPassword:getString()))
    	
            local function onReadyStateChange()
                if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then
                    local statusString = "Http Status Code:"..xhr.statusText
                    cclog(statusString)
                    cclog(xhr.response)
                else
                    cclog("xhr.readyState is:", xhr.readyState, "xhr.status is: ",xhr.status)
                end
            end
            
            xhr:registerScriptHandler(onReadyStateChange)
            xhr:send()

            cclog("waiting...")
            
    	end
    end
   
    local function LoginPostCallBack(sender, eventType)
        if eventType == ccui.TouchEventType.ended then
            cclog("post")
            
            local xhr = cc.XMLHttpRequest:new()
            xhr.responseType = cc.XMLHTTPREQUEST_RESPONSE_STRING
            xhr:open("POST", "http://127.0.0.1:8081/DoLogin")
            local params = string.format("username=%s&password=%s", txtUserName:getString(), txtPassword:getString())
            xhr:setRequestHeader("Content-Length", params:len())
            
            local function onReadyStateChange()
                if xhr.readyState == 4 and (xhr.status >= 200 and xhr.status < 207) then
                    cclog("Http Status Code:"..xhr.statusText)
                    cclog(xhr.response)
                else
                    cclog("xhr.readyState is:", xhr.readyState, "xhr.status is: ",xhr.status)
                end
            end
            xhr:registerScriptHandler(onReadyStateChange)
            xhr:send(params)

            cclog("waiting...")
        end
    end 
    
    btnLoginGet:addTouchEventListener(LoginGetCallBack)
	btnLoginPost:addTouchEventListener(LoginPostCallBack)
end



init()

return scene